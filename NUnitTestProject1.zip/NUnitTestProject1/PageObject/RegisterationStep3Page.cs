﻿using System;
using System.Collections.Generic;
using System.Text;
using OpenQA.Selenium;
using OpenQA.Selenium.Interactions;
using OpenQA.Selenium.Support.UI;
using SeleniumExtras.PageObjects;

namespace NUnitTestProject1.PageObject
{
    class RegisterationStep3Page
    {

        private IWebDriver driver;
        WebDriverWait wait;

        private String emailTxtboxLocator = "input#registration-email";
        private String passwordTxtboxLocator = "input#registration-pass1";
        private String confirmPasswordTxtboxLocator = "input#registration-pass2";
        private String lastNameTxtboxLocator = "input#registration-name2";
        private String userNameTxtboxLocator = "input#registration-user";
        private String currencyListboxLocator = "//select[@name='currency']/following-sibling::div[contains(@class,'select-selected')]";
        private String currencyValueLocator = "//select[@name='currency']/following-sibling::div[contains(@class,'select-items')]/div[contains(text(),'Toman')]";
        private String languageListboxLocator = "//select[@name='language']/following-sibling::div[contains(@class,'select-selected')]";
        private String languageValueLocator = "//select[@name='language']/following-sibling::div[contains(@class,'select-items')]/div[contains(text(),'English')]";
        private String receiveNotificationCheckboxLocator = "//span[text()='Receive Notifications ']";
        private String receiveNotificationViaInPlatformCheckboxLocator = "//span[text()='Receive Notifications via In-Platform ']";
        private String termsAndConditionCheckboxLocator = "//span[text()='I agree with the ']";
        private String ageValidationCheckboxLocator = "//span[text()='I am at least 18  years old *']";
        private String finishButtonLocator = "a[data-form='registration-step-3']";
     
        public RegisterationStep3Page(IWebDriver driver)
        {
            this.driver = driver;
            PageFactory.InitElements(driver, this);
            wait = new WebDriverWait(driver, TimeSpan.FromSeconds(10));
        }

        /*
         *  Enter Email in email textbox.
         *  @Param : email address as String
         * */
        public void enterEmail(String emailAdd)
        {
            IWebElement emailTxtbox = wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementIsVisible(By.CssSelector(emailTxtboxLocator)));
            emailTxtbox.SendKeys(emailAdd);
        }

        /*
         *  Enter password
         *  @Param : password as String
         * */
        public void enterPassword(String password)
        {
            IWebElement passwordTxtbox = driver.FindElement(By.CssSelector(passwordTxtboxLocator));
            passwordTxtbox.SendKeys(password);
        }

        /*
         *  Enter Confirm password*  
         *  @Param : Confirm password as String
         * */
        public void enterConfirmPassword(String password)
        {
            IWebElement confirmPasswordTxtbox = driver.FindElement(By.CssSelector(confirmPasswordTxtboxLocator));
            confirmPasswordTxtbox.SendKeys(password);
        }

        /*
         *  Enter Last Name 
         *  @Param : Last Name as String
         * */
        public void enterLastName(String lastName)
        {
            IWebElement lastNameTxtbox = driver.FindElement(By.CssSelector(lastNameTxtboxLocator));
            lastNameTxtbox.SendKeys(lastName);
        }

        /*
         *  Enter User Name
         *  @Param : User Name as String
         * */
        public void enterUserName(String lastName)
        {
            IWebElement userNameTxtbox = driver.FindElement(By.CssSelector(userNameTxtboxLocator));
            userNameTxtbox.SendKeys(lastName);
        }

        /*
         *  Select Currency
         *  @Param : Curreny as String
         * */
        public void selectCurrency(String currency)
        {
            IWebElement currencyListbox = driver.FindElement(By.XPath(currencyListboxLocator));
            currencyListbox.Click();
            IWebElement currencyValue = driver.FindElement(By.XPath(currencyValueLocator.Replace("Toman", currency)));
            currencyValue.Click();
        }

        /*
         *  Select Language
         *  @Param : Language as String
         * */
        public void selectLanguage(String language)
        {
            IWebElement languageListbox = driver.FindElement(By.XPath(languageListboxLocator));
            languageListbox.Click();
            IWebElement languageValue = driver.FindElement(By.XPath(languageValueLocator.Replace("Toman", language)));
            languageValue.Click();
        }

        /*
         *  Select Receive Notification Checkbox
         * */
        public void selectReceiveNotificationCheckbox()
        {
            IWebElement receiveNotificationCheckbox = driver.FindElement(By.XPath(receiveNotificationCheckboxLocator));
            receiveNotificationCheckbox.Click();
        }

        /*
         *  Select Receive Notification In Platform Checkbox
         * */
        public void selectReceiveNotificationViaInPlatformCheckbox()
        {
            IWebElement receiveNotificationViaInPlatformCheckbox = driver.FindElement(By.XPath(receiveNotificationViaInPlatformCheckboxLocator));
            receiveNotificationViaInPlatformCheckbox.Click();
        }

        /*
         *  Select Terms and Conditions Checkbox
         * */
        public void selectTermsAndConditionCheckbox()
        {
            Actions action = new Actions(driver);
            IWebElement termsAndConditionCheckbox = driver.FindElement(By.XPath(termsAndConditionCheckboxLocator));
            action.MoveToElement(termsAndConditionCheckbox).MoveByOffset(0, 9).Click().Build().Perform();
        }

        /*
         *  Select Age Validation Checkbox
         * */
        public void selectAgeValidationCheckbox()
        {
            IWebElement ageValidationCheckbox = driver.FindElement(By.XPath(ageValidationCheckboxLocator));
            ageValidationCheckbox.Click();
        }

        /*
         *  Click On Finish Button
         * */
        public RegisterationStep4Page clickFinishButton()
        {
            IJavaScriptExecutor js = (IJavaScriptExecutor)driver;
            IWebElement finishButton = driver.FindElement(By.CssSelector(finishButtonLocator));
            js.ExecuteScript("arguments[0].click();",finishButton);
            return new RegisterationStep4Page(driver);
        }
    }
}
