﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using SeleniumExtras.PageObjects;
using System;
using System.Collections.Generic;
using System.Text;

namespace NUnitTestProject1.PageObject
{
    class RegisterationStep1Page
    {
        private IWebDriver driver;
        WebDriverWait wait;

        private String countrycodeListBoxLocator = "//div[@class='step-popup registration-steps step1']//div[@class='select-selected']";
        private String countrycodeValueLocator = "//form[@id='insert-mobile-number']//div[@class='step-popup registration-steps step1']//div[text()='+98']";
        private String phoneNumberTextboxLocator = "input[id = 'phone-number phone-main']";
        private String continueButtonLocator = "form#insert-mobile-number a[data-form='insert-mobile-number']";

        public RegisterationStep1Page(IWebDriver driver)
        {
            this.driver = driver;
            PageFactory.InitElements(driver, this);
            wait = new WebDriverWait(driver, TimeSpan.FromSeconds(10));
        }

        /*
         *  Enter Phone Number
         *  @Param :  Code Value as String and Phone Number as String
         * */
        public void enterPhoneNumber(String codeValue, String phoneNumber)
        {
            IWebElement countrycodeListBox = wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementIsVisible(By.XPath(countrycodeListBoxLocator)));
            countrycodeListBox.Click();
            IWebElement countrycode98 = driver.FindElement(By.XPath(countrycodeValueLocator.Replace("98", codeValue)));
            countrycode98.Click();
            IWebElement phoneNumberTxtbox = driver.FindElement(By.CssSelector(phoneNumberTextboxLocator));
            phoneNumberTxtbox.SendKeys(phoneNumber);
        }

        /*
         *  Click on Continue Button
         * */
        public RegisterationStep2Page clickContinueButton()
        {
            IWebElement continueButton = driver.FindElement(By.CssSelector(continueButtonLocator));
            continueButton.Click();
            return new RegisterationStep2Page(driver);
        }

    }
}
