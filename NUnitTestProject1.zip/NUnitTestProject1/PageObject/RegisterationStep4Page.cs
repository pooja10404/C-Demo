﻿using System;
using System.Collections.Generic;
using System.Text;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using SeleniumExtras.PageObjects;

namespace NUnitTestProject1.PageObject
{
    class RegisterationStep4Page
    {
        private IWebDriver driver;
        WebDriverWait wait;

        private String emailVerificationSentText = "//div[@id='verification-emeil--you']/h3[contains(text(),'Email verification has been sent to your email')]";

        public RegisterationStep4Page(IWebDriver driver)
        {
            this.driver = driver;
            PageFactory.InitElements(driver, this);
            wait = new WebDriverWait(driver, TimeSpan.FromSeconds(10));
        }

        /*
         *  Check Presence of Verification Code
         * */
        public Boolean enterVerificationCode()
        {
            IWebElement verificationCode = wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementIsVisible(By.XPath(emailVerificationSentText)));
            if (driver.FindElement(By.XPath(emailVerificationSentText)).Displayed)
            {
                return true;
            }
            else
            {
                return false;
            }
                
        }
    }
}
