﻿using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Text;
using SeleniumExtras.PageObjects;
using OpenQA.Selenium.Support.UI;

namespace NUnitTestProject1.PageObject
{
    class LandingPage
    {
        private IWebDriver driver;
        WebDriverWait wait;

        private String registerLinkLocator = "a#popups";

        public LandingPage(IWebDriver driver)
        {
            this.driver = driver;
            PageFactory.InitElements(driver, this);
            wait = new WebDriverWait(driver, TimeSpan.FromSeconds(10));
        }

        /*
         * Click on Register link on the left top.
         * */
        public RegisterationStep1Page clickOnRegisterLink()
        {
            IWebElement registerLink = wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementExists(By.CssSelector(registerLinkLocator)));
            registerLink.Click();
            return new RegisterationStep1Page(driver);
        }

    }
}
