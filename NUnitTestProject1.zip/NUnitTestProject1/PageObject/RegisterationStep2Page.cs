﻿using System;
using System.Collections.Generic;
using System.Text;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using SeleniumExtras.PageObjects;

namespace NUnitTestProject1.PageObject
{
    class RegisterationStep2Page
    {
        private IWebDriver driver;
        WebDriverWait wait;

        private String verificationCodeLocator = "form#validate-mobile-number input#verification-code";
        private String enterCodeButtonLocator = "form#validate-mobile-number a[data-method='verifySms']";

        public RegisterationStep2Page(IWebDriver driver)
        {
            this.driver = driver;
            PageFactory.InitElements(driver, this);
            wait = new WebDriverWait(driver, TimeSpan.FromSeconds(10));
        }

        /*
         *  Enter Verification Code
         *  @Param : Code Value as String
         * */
        public void enterVerificationCode(String codeValue)
        {
            IWebElement verificationCode = wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementIsVisible(By.CssSelector(verificationCodeLocator)));
            verificationCode.SendKeys(codeValue);
        }

        /*
         *  Click on Enter Code Button
         * */
        public RegisterationStep3Page clickEnterCodeButton()
        {
            IWebElement enterCodeButton= driver.FindElement(By.CssSelector(enterCodeButtonLocator));
            enterCodeButton.Click();
            return new RegisterationStep3Page(driver);
        }
    }
}
