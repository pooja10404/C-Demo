using NUnit.Framework;
using NUnitTestProject1.PageObject;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using System;
using System.IO;

namespace NUnitTestProject1
{
    public class RegistrationTests
    {
        private LandingPage landingPage;
        private RegisterationStep1Page registerationStep1Page;
        private RegisterationStep2Page registerationStep2Page;
        private RegisterationStep3Page registerationStep3Page;
        private RegisterationStep4Page registerationStep4Page;
        IWebDriver driver;

        [SetUp]
        public void Setup()
        {
            string pathToChromeDriver = AppDomain.CurrentDomain.BaseDirectory + "..\\..\\..\\ChromeDriver";
            driver = new ChromeDriver(pathToChromeDriver);
            driver.Url = "https://umbracotest109.betmaster.xyz/en/";
            driver.Manage().Window.Maximize();
        }

        [Test]
        public void TestRegistrationWithValidCredentials()
        {
            landingPage = new LandingPage(driver);
            registerationStep1Page = landingPage.clickOnRegisterLink();
            registerationStep1Page.enterPhoneNumber("98", "9193439458");
            registerationStep2Page = registerationStep1Page.clickContinueButton();
            registerationStep2Page.enterVerificationCode("999999");
            registerationStep3Page = registerationStep2Page.clickEnterCodeButton();
            registerationStep3Page.enterEmail("test@mailinator.com");
            registerationStep3Page.enterPassword("MyPassword1");
            registerationStep3Page.enterConfirmPassword("MyPassword1");
            registerationStep3Page.enterLastName("LastName");
            registerationStep3Page.enterUserName("uName");
            registerationStep3Page.selectCurrency("Toman");
            registerationStep3Page.selectLanguage("English");
            registerationStep3Page.selectReceiveNotificationCheckbox();
            registerationStep3Page.selectReceiveNotificationViaInPlatformCheckbox();
            registerationStep3Page.selectTermsAndConditionCheckbox();
            registerationStep3Page.selectAgeValidationCheckbox();
            registerationStep4Page = registerationStep3Page.clickFinishButton();
            Assert.IsTrue(registerationStep4Page.enterVerificationCode());
        }

        [TearDown]
        public void closeBrowser()
        {
            driver.Close();
            driver.Quit();
            driver = null;
        }
    }
}